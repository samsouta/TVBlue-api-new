<?php

namespace Database\Seeders;

use App\Models\Movie;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class MovieSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {


        $movies = [
            [
                "id" => 242,
                "title" => "Petite stepsister gets her tight pussy filled with cum after getting drilled in different positions",
                "description" => "video",
                "posted_date" => "2024-12-02 05:00:00",
                "genre" => "russia",
                "img_path" => "https://www.pornkut.com/get_file/0/2de85f004e62b96ee2668ab7a1ca0745f5933141b5/40000/40820/screenshots/4.jpg?t=1734619554",
                "duration" => "724",
                "view_count" => "9",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://www.pornkut.com/embed/40820"
            ],
            [
                "id" => 243,
                "title" => "Petite stepsister Chanel Shortcake gets her tight pussy drilled and mouth filled with cum",
                "description" => "video",
                "posted_date" => "2024-12-02 05:00:00",
                "genre" => "russia",
                "img_path" => "https://www.pornkut.com/get_file/0/c896a43c38f434c7b1e5538352bb480fa999931c2f/18000/18419/screenshots/9.jpg?t=1734619554",
                "duration" => "751",
                "view_count" => "10",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://www.pornkut.com/embed/18419"
            ],
            [
                "id" => 244,
                "title" => "SonyaXMark's wet T-shirt squirts while she gives a sloppy blowjob and gets her tight pussy pounded",
                "description" => "video",
                "posted_date" => "2024-12-02 05:00:00",
                "genre" => "russia",
                "img_path" => "https://www.pornkut.com/get_file/0/543deeb36fb9670e1c033901ee7e6bfd3e29039715/50000/50179/screenshots/2.jpg?t=1734619554",
                "duration" => "812",
                "view_count" => "3",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://www.pornkut.com/embed/50179"
            ],
            [
                "id" => 245,
                "title" => "CJ Miles gives a sloppy POV blowjob and gets her tight pussy pounded",
                "description" => "video",
                "posted_date" => "2024-12-02 05:00:00",
                "genre" => "russia",
                "img_path" => "https://www.pornkut.com/get_file/0/03d20424603faa76043b24127ef07424c6d62d0c5d/42000/42393/screenshots/9.jpg?t=1734619554",
                "duration" => "733",
                "view_count" => "7",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://www.pornkut.com/embed/42393"
            ],
            [
                "id" => 246,
                "title" => "Hiyouth gives her neighbor a sloppy blowjob and gets pounded doggy-style in POV",
                "description" => "video",
                "posted_date" => "2024-12-02 05:00:00",
                "genre" => "russia",
                "img_path" => "https://www.pornkut.com/get_file/0/9f5cb922103b6136088772d5132a9c05234463e6f6/40000/40553/screenshots/9.jpg?t=1734619554",
                "duration" => "620",
                "view_count" => "9",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://www.pornkut.com/embed/40553"
            ],
            [
                "id" => 248,
                "title" => "Creamy Spot gets off on riding a massive dildo on webcam",
                "description" => "video",
                "posted_date" => "2024-12-02 05:00:00",
                "img_path" => "https://www.pornkut.com/get_file/0/6c4bf0765d36d9dad89c994b1fca59226ebebcef81/53000/53229/screenshots/2.jpg?t=1734619554",
                "duration" => "718",
                "view_count" => "3",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://www.pornkut.com/embed/53229"
            ],
            [
                "id" => 249,
                "title" => "Creamy Spot's bald pussy gets filled with cum while playing with a huge dildo in white stockings",
                "description" => "video",
                "posted_date" => "2024-12-02 05:00:00",
                "genre" => "russia",
                "img_path" => "https://www.pornkut.com/get_file/0/514a5eb7e8b4a2aa29ab74250fb4c08c1d9400ed3f/53000/53194/screenshots/1.jpg?t=1734619554",
                "duration" => "748",
                "view_count" => "7",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://www.pornkut.com/embed/53194"
            ],
            [
                "id" => 191,
                "title" => "Amateur Blonde Kid - Homemade Creampies Compilation",
                "description" => "video",
                "posted_date" => "2024-11-26 05:00:00",
                "genre" => "russia",
                "img_path" => "https://www.pornkut.com/get_file/0/9acf234682002a5b07f89da3ec80b248d83be5138c/56000/56915/screenshots/1.jpg?t=1734619554",
                "duration" => "704",
                "view_count" => "4",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://www.pornkut.com/embed/67098"
            ],
            [
                "id" => 104,
                "title" => "ချစ်စရာကြောင်",
                "description" => "video",
                "posted_date" => "2024-11-18 05:00:00",
                "genre" => "russia",
                "img_path" => "https://www.pornkut.com/get_file/0/7ed0cee88b49bb4009b0de1731fbb13560754d7c94/61000/61227/screenshots/4.jpg?t=1734619554",
                "duration" => "950",
                "view_count" => "47",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://rusoska.com/embed/188218"
            ],
            [
                "id" => 105,
                "title" => "ာရုံခံစားမှု Creampies၊ Squirting Passions နှင့် Monster Cock Adventures",
                "description" => "video",
                "posted_date" => "2024-11-18 05:00:00",
                "genre" => "russia",
                "img_path" => "https://www.pornkut.com/get_file/0/73ec97b61db3cc29f8c2d4db40f658e6045756a239/66000/66586/screenshots/1.jpg?t=1734619554",
                "duration" => "533",
                "view_count" => "33",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://www.pornkut.com/embed/66586"
            ],
            [
                "id" => 106,
                "title" => "စိုစွတ်သော Creamy Pussy",
                "description" => "video",
                "posted_date" => "2024-11-18 05:00:00",
                "genre" => "russia",
                "img_path" => "https://www.pornkut.com/get_file/0/f85d51063f5a05546e3f2819df0008a5a32547f3a8/65000/65698/screenshots/1.jpg?t=1734619554",
                "duration" => "803",
                "view_count" => "26",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://www.pornkut.com/embed/65698"
            ],
            [
                "id" => 107,
                "title" => "ဟယ်လိုရီပွဲတော်အတွင်း Creamy Spot သည် သူမ၏ တင်းကျပ်သော အပေါက်များကို",
                "description" => "video",
                "posted_date" => "2024-11-18 05:00:00",
                "genre" => "russia",
                "img_path" => "https://www.pornkut.com/get_file/0/52b112d552bfcc033f960c0e3a624fc74aace4fa85/64000/64769/screenshots/2.jpg?t=1734619554",
                "duration" => "842",
                "view_count" => "11",
                "rating_total" => "0",
                "rating_count" => "1",
                "url" => "https://www.pornkut.com/embed/64769/"
            ]
        ];
        
        // You can now use the $data array in your PHP code.
               
               





        foreach ($movies as $movie) {
            Movie::updateOrCreate(
                ['video_url' => $movie['url']], // Unique constraint field
                [
                    'title' => $movie['title'],
                    'description' => $movie['title'],
                    'posted_date' => Carbon::parse(),
                    'duration' => $movie['duration'],
                    'view_count' => $movie['view_count'],
                    'rating_total' => $movie['rating_total'],
                    'rating_count' => $movie['rating_count'],
                    'language' => 'russia', // Example language
                    'released_year' => '2024-12-20',
                    'thumbnail_url' => $movie['img_path'],
                    'is_featured' => false,
                    'genre_id' => 12,  // Example genre ID
                    'sub_genre_id' => 40, // Example sub-genre ID
                ]
            );
        }
    }
}
